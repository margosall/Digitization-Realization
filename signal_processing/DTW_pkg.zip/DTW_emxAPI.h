/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DTW_emxAPI.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 07-Nov-2019 22:10:58
 */

#ifndef DTW_EMXAPI_H
#define DTW_EMXAPI_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "DTW_types.h"

/* Function Declarations */
extern emxArray_int16_T *emxCreateND_int16_T(int numDimensions, int *size);
extern emxArray_int16_T *emxCreateWrapperND_int16_T(short *data, int
  numDimensions, int *size);
extern emxArray_int16_T *emxCreateWrapper_int16_T(short *data, int rows, int
  cols);
extern emxArray_int16_T *emxCreate_int16_T(int rows, int cols);
extern void emxDestroyArray_int16_T(emxArray_int16_T *emxArray);
extern void emxInitArray_int16_T(emxArray_int16_T **pEmxArray, int numDimensions);

#endif

/*
 * File trailer for DTW_emxAPI.h
 *
 * [EOF]
 */
