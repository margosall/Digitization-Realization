/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DTW_emxAPI.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 07-Nov-2019 22:10:58
 */

/* Include Files */
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "DTW.h"
#include "DTW_emxAPI.h"
#include "DTW_emxutil.h"

/* Function Definitions */

/*
 * Arguments    : int numDimensions
 *                int *size
 * Return Type  : emxArray_int16_T *
 */
emxArray_int16_T *emxCreateND_int16_T(int numDimensions, int *size)
{
  emxArray_int16_T *emx;
  int numEl;
  int i;
  emxInit_int16_T(&emx, numDimensions);
  numEl = 1;
  for (i = 0; i < numDimensions; i++) {
    numEl *= size[i];
    emx->size[i] = size[i];
  }

  emx->data = (short *)calloc((unsigned int)numEl, sizeof(short));
  emx->numDimensions = numDimensions;
  emx->allocatedSize = numEl;
  return emx;
}

/*
 * Arguments    : short *data
 *                int numDimensions
 *                int *size
 * Return Type  : emxArray_int16_T *
 */
emxArray_int16_T *emxCreateWrapperND_int16_T(short *data, int numDimensions, int
  *size)
{
  emxArray_int16_T *emx;
  int numEl;
  int i;
  emxInit_int16_T(&emx, numDimensions);
  numEl = 1;
  for (i = 0; i < numDimensions; i++) {
    numEl *= size[i];
    emx->size[i] = size[i];
  }

  emx->data = data;
  emx->numDimensions = numDimensions;
  emx->allocatedSize = numEl;
  emx->canFreeData = false;
  return emx;
}

/*
 * Arguments    : short *data
 *                int rows
 *                int cols
 * Return Type  : emxArray_int16_T *
 */
emxArray_int16_T *emxCreateWrapper_int16_T(short *data, int rows, int cols)
{
  emxArray_int16_T *emx;
  emxInit_int16_T(&emx, 2);
  emx->size[0] = rows;
  emx->size[1] = cols;
  emx->data = data;
  emx->numDimensions = 2;
  emx->allocatedSize = rows * cols;
  emx->canFreeData = false;
  return emx;
}

/*
 * Arguments    : int rows
 *                int cols
 * Return Type  : emxArray_int16_T *
 */
emxArray_int16_T *emxCreate_int16_T(int rows, int cols)
{
  emxArray_int16_T *emx;
  int numEl;
  emxInit_int16_T(&emx, 2);
  emx->size[0] = rows;
  numEl = rows * cols;
  emx->size[1] = cols;
  emx->data = (short *)calloc((unsigned int)numEl, sizeof(short));
  emx->numDimensions = 2;
  emx->allocatedSize = numEl;
  return emx;
}

/*
 * Arguments    : emxArray_int16_T *emxArray
 * Return Type  : void
 */
void emxDestroyArray_int16_T(emxArray_int16_T *emxArray)
{
  emxFree_int16_T(&emxArray);
}

/*
 * Arguments    : emxArray_int16_T **pEmxArray
 *                int numDimensions
 * Return Type  : void
 */
void emxInitArray_int16_T(emxArray_int16_T **pEmxArray, int numDimensions)
{
  emxInit_int16_T(pEmxArray, numDimensions);
}

/*
 * File trailer for DTW_emxAPI.c
 *
 * [EOF]
 */
