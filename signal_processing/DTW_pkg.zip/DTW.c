/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DTW.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 07-Nov-2019 22:10:58
 */

/* Include Files */
#include <math.h>
#include "rt_nonfinite.h"
#include "DTW.h"
#include "DTW_emxutil.h"

/* Function Declarations */
static double rt_roundd_snf(double u);

/* Function Definitions */

/*
 * Arguments    : double u
 * Return Type  : double
 */
static double rt_roundd_snf(double u)
{
  double y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/*
 * DTW for C Summary of this function goes here
 *    Detailed explanation goes here
 * Arguments    : const emxArray_int16_T *signal1
 *                const emxArray_int16_T *signal2
 * Return Type  : double
 */
double DTW(const emxArray_int16_T *signal1, const emxArray_int16_T *signal2)
{
  double distance;
  emxArray_real_T *path;
  int i0;
  int loop_ub;
  int i1;
  int j;
  double min_check_vector[3];
  int i2;
  double ex;
  int i3;
  int i4;
  short i5;
  emxInit_real_T(&path, 2);
  i0 = path->size[0] * path->size[1];
  path->size[0] = signal1->size[1];
  path->size[1] = signal2->size[1];
  emxEnsureCapacity_real_T(path, i0);
  loop_ub = signal1->size[1] * signal2->size[1];
  for (i0 = 0; i0 < loop_ub; i0++) {
    path->data[i0] = 0.0;
  }

  i0 = signal1->size[1];
  for (loop_ub = 0; loop_ub <= i0 - 2; loop_ub++) {
    path->data[1 + loop_ub] = rtInf;
  }

  i0 = signal2->size[1];
  for (loop_ub = 0; loop_ub <= i0 - 2; loop_ub++) {
    path->data[path->size[0] * (1 + loop_ub)] = rtInf;
  }

  i0 = signal1->size[1];
  for (loop_ub = 0; loop_ub <= i0 - 2; loop_ub++) {
    i1 = signal2->size[1];
    for (j = 0; j <= i1 - 2; j++) {
      min_check_vector[0] = path->data[loop_ub + path->size[0] * (1 + j)];
      min_check_vector[1] = path->data[loop_ub + path->size[0] * j];
      min_check_vector[2] = path->data[(loop_ub + path->size[0] * j) + 1];
      i2 = signal1->data[loop_ub + 1] - signal2->data[j + 1];
      if (i2 > 32767) {
        i2 = 32767;
      } else {
        if (i2 < -32768) {
          i2 = -32768;
        }
      }

      ex = min_check_vector[0];
      if (min_check_vector[0] > min_check_vector[1]) {
        ex = min_check_vector[1];
      }

      if (ex > min_check_vector[2]) {
        ex = min_check_vector[2];
      }

      i3 = -(short)i2;
      if (i3 > 32767) {
        i3 = 32767;
      }

      if ((short)i2 < 0) {
        i4 = i3;
      } else {
        i4 = (short)i2;
      }

      ex = rt_roundd_snf((double)i4 + ex);
      if (ex < 32768.0) {
        if (ex >= -32768.0) {
          i5 = (short)ex;
        } else {
          i5 = MIN_int16_T;
        }
      } else if (ex >= 32768.0) {
        i5 = MAX_int16_T;
      } else {
        i5 = 0;
      }

      path->data[(loop_ub + path->size[0] * (1 + j)) + 1] = i5;
    }
  }

  distance = path->data[(signal1->size[1] + path->size[0] * (signal2->size[1] -
    1)) - 1];
  emxFree_real_T(&path);
  return distance;
}

/*
 * File trailer for DTW.c
 *
 * [EOF]
 */
