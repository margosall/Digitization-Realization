/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DTW_terminate.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 07-Nov-2019 22:10:58
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "DTW.h"
#include "DTW_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void DTW_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for DTW_terminate.c
 *
 * [EOF]
 */
