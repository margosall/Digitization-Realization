/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DTW.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 07-Nov-2019 22:10:58
 */

#ifndef DTW_H
#define DTW_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "DTW_types.h"

/* Function Declarations */
extern double DTW(const emxArray_int16_T *signal1, const emxArray_int16_T
                  *signal2);

#endif

/*
 * File trailer for DTW.h
 *
 * [EOF]
 */
