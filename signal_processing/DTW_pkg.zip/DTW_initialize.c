/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: DTW_initialize.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 07-Nov-2019 22:10:58
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "DTW.h"
#include "DTW_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void DTW_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for DTW_initialize.c
 *
 * [EOF]
 */
